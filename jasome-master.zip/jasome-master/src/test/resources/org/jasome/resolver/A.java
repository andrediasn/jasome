package org.jasome.resolver;

public class A {
    public void print() {
        System.out.println("Hello!");
    }
}