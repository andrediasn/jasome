package org.jasome.resolver;

import org.jasome.resolver.A;

public class Test {
    A a;

    public void doStuff(A a) {
        a.print();
    }
}