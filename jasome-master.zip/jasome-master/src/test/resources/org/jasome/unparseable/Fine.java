package org.jasome.unparseable;

class Fine {
    public void hi() {
        System.out.println("hi");
    }
}